package com.example.shanu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShanuApplicationTests {

	@Test
	void contextLoads() {
	}

}
